#include "mbed.h"
#include "SDFileSystem.h"
#include "wave_player.h"

Serial pc(USBTX, USBRX);
//SD CARD
SDFileSystem sd(D11, D12, D13, PC_9, "sd"); //446RE ,mosi, miso, sclk, cs
AnalogOut DACout (A2);
wave_player waver (& DACout);
FILE *fp;
FILE * wave_file;
//MOTORES 
PwmOut motordc1(PB_14);// pin servo 
PwmOut motordc2(PB_13);// pin servo 
PwmOut servo(PB_8);// pin servo 
DigitalOut laser(PB_9);
int cont=0;// CONTADOR MOTOR DC
int posi=700;
int avan=300;

Ticker motord;
Ticker motors;

// SENSOR DE COLOR 
InterruptIn in(PA_11);
DigitalOut s0(PC_8), s1(PC_6); // s2(p7), s3(p8)
BusOut setColor(PC_5,PA_12); //(LSB pin,..., MSB pin): (s3, s2). Red: 0, Blue: 1, Clear: 2, Green: 3.
Timer t;

float period = 0; // This is the period between interrupts in microseconds
float freq = 0,freq1=0;
int n;
int color; // Color
float red,blue,green,clear;
int cont2=0;// CONTADOR COLOR
char datosensor;


 void mservo(){// TICKET SERVO
        
         posi=posi+avan;
         servo.pulsewidth_us(posi); 
         
         if(posi<=700||posi>=1700){
           avan=-avan;
           }  
           laser=!laser;
           
          
       }  
       
        void mdc(){ // TICKET MOTOR DC
        if(cont%2==0){
         motordc1=1;
         motordc2=0;}
         else{
         motordc1=0;
         motordc2=1;}
         
         cont++;
         if(cont==50){cont=0;}
        }      
      
      

void print() {  // Print to PC
    switch (color) {
        case 0:
            pc.printf(" Red: \t\t%.2f Hz, \t%.2f us\r\n", freq1, period);
            red=freq1;
            cont2++;
            break;
        case 1:
            blue=freq1;
            cont2++;
            pc.printf(" Blue: \t\t%.2f Hz, \t%.2f us\r\n", blue, period);
            break;
        case 2:
            pc.printf(" Clear: \t%.2f Hz, \t%.2f us\r\n", freq1, period);
            clear=freq1;
            cont2++;
            break;
        case 3:
            pc.printf(" Green: \t%.2f Hz, \t%.2f us\r\n", freq1, period);
            pc.printf("\r\n");
            green=freq1;   
            cont2++;
            break;
            
    }
    if(cont2==4){
            if(green>red&&blue) {
             pc.printf("\n\r VERDE");
             datosensor='V';
             }
             if(red>green&&blue) {
            pc.printf("\n\r ROJO");
            datosensor='R';
             }
             //if(blue>green&&red) {
             //pc.printf("\n\r AZUL");
             //}
             cont2=0;}
    
}

void time() {
   
   if (n>70) { // Wait 100 interrupts
        period = t.read_us()/(float)n; // Get time
        freq = (1/period)*180000000;   // Convert period (in us) to frequency (Hz). Works up to 100kHz.
        freq1=freq*0.001;
        n = 0;

        print(); // Print values to PC

        color++;
        if (color > 3) color = 0;
        setColor = color;
        wait(0.5);
        t.reset(); // Reset timer and wait for next interrupt
    }
    n++;
}

      
      
int main() {
        // CONFIGURACION MOTORES 
         servo.period_ms(20);
         servo.pulsewidth_us(500); 
         motordc1.period_ms(16);
         motordc1.write(0.5);
         motordc2.period_ms(16);
         motordc2.write(0.5);
         motord.attach(&mdc,2.5);
         motors.attach(&mservo,2.6);
         pc.baud(9600);
         //SENSOR
         in.mode(PullDown); // Set the pin to Pull Down mode.
    wait(1);
    n = 0;
    color = 0;
    setColor = color;

    s0 = 1;
    s1 = 1; // Frequency 2% = 12 kHz full-scale.
   
    in.rise(&time);  // Set up the interrupt for rising edge
    t.start();       // Start the timer
         
         // PRUEBA SD CARD
    printf("Hello World!\n");   
   
    mkdir("/sd/carpeta2", 0777);
    
    fp = fopen("/sd/carpeta2/sdtest.txt", "w");
    if(fp == NULL) {
        error("Could not open file for write\n");
        pc.printf("Could not open file for write\n");
    }
    fprintf(fp, "esta funcion es para grabar en la sd");
    fclose(fp); 
    
    printf("Goodbye World!\n");
    pc.printf("Goodbye World!\n");
    
    
   

     wave_file = fopen("/sd/bienvenido.wav","r");
     waver.play(wave_file);
     
      wave_file = fopen("/sd/juego.wav","r");
     waver.play(wave_file);
      
      
    while(true){
        
    }
 
}